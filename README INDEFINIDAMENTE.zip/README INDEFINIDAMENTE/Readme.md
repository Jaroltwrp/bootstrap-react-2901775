# Indefinidamente
Indefinidamente una plataforma de aprendizaje interactivo que tiene como objetivo mostrar al público el verdadero significado de la salud mental

## Mockups de la aplicación
<img src="imagenes/Captura 1 .png" height="400">
<img src="imagenes/Captura 2 .png" height="400">

## Desarrollado con
- HTML & CSS
- JavaScript

## Diseño
- Figma
- Illustrator

## Animaciones
- After Effects

### Equipo
- Jarol Carrascal
- Laura Peña 